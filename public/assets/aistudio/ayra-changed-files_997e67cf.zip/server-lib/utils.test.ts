/**
 * Unit tests for the dependency-free server helpers.
 * Run with:  node --test server-lib/        (Node 22+, no packages required)
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import type { AddressInfo } from 'node:net';
import { Buffer } from 'node:buffer';
import dns from 'node:dns';
import {
  RateLimiter,
  UrlBlockedError,
  buildChatContents,
  cleanForSpeech,
  estimateReadingTime,
  extractJsonObject,
  htmlToText,
  isOriginAllowed,
  isPrivateAddress,
  normalizeHistory,
  parseAudioMime,
  parseCsv,
  parseImageData,
  parsePublicHttpUrl,
  pcmToWav,
  readPositiveInt,
  readText,
  safeEqual,
  sanitizeAction,
} from './utils.ts';
import { FetchPageError, fetchPageWithPolicy, fetchPublicPage, guardedLookup } from './safeFetch.ts';

/* ---------------- validation ---------------- */

test('readText enforces presence and length', () => {
  assert.equal(readText('  hi  ', 10), 'hi');
  assert.equal(readText('', 10), null);
  assert.equal(readText('   ', 10), null);
  assert.equal(readText('x'.repeat(11), 10), null);
  assert.equal(readText(42, 10), null);
});

test('readPositiveInt / parseCsv / safeEqual', () => {
  assert.equal(readPositiveInt('5000', 1, 1, 10000), 5000);
  assert.equal(readPositiveInt('abc', 7), 7);
  assert.equal(readPositiveInt('-3', 7), 7);
  assert.equal(readPositiveInt(undefined, 9), 9);
  assert.deepEqual(parseCsv(' a, b ,,c'), ['a', 'b', 'c']);
  assert.deepEqual(parseCsv(undefined), []);
  assert.equal(safeEqual('secret', 'secret'), true);
  assert.equal(safeEqual('secret', 'secreT'), false);
  assert.equal(safeEqual('a', 'ab'), false);
});

/* ---------------- history ---------------- */

test('normalizeHistory maps roles, merges runs and starts with a user turn', () => {
  const out = normalizeHistory([
    { role: 'assistant', text: 'welcome' }, // leading model turn must be dropped
    { role: 'user', text: 'hi' },
    { role: 'user', content: 'are you there?' },
    { role: 'ayra', text: 'yes' },
    { role: 'system', text: 'ignored' },
    { role: 'user', text: '   ' },
    null,
  ]);
  assert.deepEqual(out, [
    { role: 'user', parts: [{ text: 'hi\nare you there?' }] },
    { role: 'model', parts: [{ text: 'yes' }] },
  ]);
  assert.deepEqual(normalizeHistory('nope'), []);
});

test('normalizeHistory keeps only the most recent turns and truncates long text', () => {
  const many = Array.from({ length: 40 }, (_, i) => ({ role: i % 2 ? 'model' : 'user', text: `m${i}` }));
  const out = normalizeHistory(many, 6);
  assert.ok(out.length <= 6);
  assert.equal(out[0].role, 'user');
  assert.equal(normalizeHistory([{ role: 'user', text: 'x'.repeat(5000) }], 16, 100)[0].parts[0].text.length, 100);
});

test('buildChatContents appends or merges the new user message', () => {
  const history = normalizeHistory([
    { role: 'user', text: 'a' },
    { role: 'model', text: 'b' },
  ]);
  const appended = buildChatContents(history, 'c');
  assert.deepEqual(appended.map((t) => t.role), ['user', 'model', 'user']);
  assert.equal(appended[2].parts[0].text, 'c');

  const merged = buildChatContents(normalizeHistory([{ role: 'user', text: 'a' }]), 'c');
  assert.equal(merged.length, 1);
  assert.equal(merged[0].parts[0].text, 'a\nc');
  assert.equal(history.length, 2, 'input must not be mutated');
});

/* ---------------- model output ---------------- */

test('extractJsonObject handles plain, fenced and embedded JSON', () => {
  assert.deepEqual(extractJsonObject('{"a":1}'), { a: 1 });
  assert.deepEqual(extractJsonObject('```json\n{"a":2}\n```'), { a: 2 });
  assert.deepEqual(extractJsonObject('Sure! {"a":3} hope that helps'), { a: 3 });
  assert.equal(extractJsonObject('just words'), null);
  assert.equal(extractJsonObject('[1,2,3]'), null);
  assert.equal(extractJsonObject(''), null);
  assert.equal(extractJsonObject(undefined), null);
});

test('sanitizeAction: calls always require confirmation and need a valid number', () => {
  const ok = sanitizeAction({
    type: 'call',
    title: 'Call Ahmad',
    description: 'Dial Ahmad',
    payload: { number: '+92 300 1234567', contactName: 'Ahmad', evil: 'x' },
    requiresConfirmation: false, // model tries to skip confirmation
  });
  assert.ok(ok);
  assert.equal(ok.requiresConfirmation, true);
  assert.deepEqual(ok.payload, { number: '+92 300 1234567', contactName: 'Ahmad' });

  assert.equal(sanitizeAction({ type: 'call', payload: { number: 'abc' } }), null);
  assert.equal(sanitizeAction({ type: 'call', payload: {} }), null);
});

test('sanitizeAction: rejects unsafe or malformed actions', () => {
  assert.equal(sanitizeAction(null), null);
  assert.equal(sanitizeAction({ type: 'format_disk', payload: {} }), null);
  assert.equal(sanitizeAction({ type: 'open_url', payload: { url: 'javascript:alert(1)' } }), null);
  assert.equal(sanitizeAction({ type: 'open_url', payload: { url: 'file:///etc/passwd' } }), null);
  assert.equal(sanitizeAction({ type: 'alarm', payload: { time: '25:99' } }), null);
  assert.equal(sanitizeAction({ type: 'open_app', payload: {} }), null);
  const url = sanitizeAction({ type: 'open_url', payload: { url: 'https://example.com/a' }, requiresConfirmation: false });
  assert.ok(url);
  assert.equal(url.requiresConfirmation, true);
  const alarm = sanitizeAction({ type: 'alarm', payload: { time: '07:30', label: 'Gym' } });
  assert.ok(alarm);
  assert.equal(alarm.requiresConfirmation, true);
});

test('sanitizeAction: harmless actions keep the model confirmation flag', () => {
  const weather = sanitizeAction({ type: 'weather', payload: { city: 'Lahore' }, requiresConfirmation: false });
  assert.ok(weather);
  assert.equal(weather.requiresConfirmation, false);
  const unspecified = sanitizeAction({ type: 'note', payload: { content: 'milk' } });
  assert.ok(unspecified);
  assert.equal(unspecified.requiresConfirmation, true);
});

/* ---------------- images & audio ---------------- */

test('parseImageData validates mime, base64 and size', () => {
  const png = Buffer.from('hello world').toString('base64');
  const ok = parseImageData(`data:image/png;base64,${png}`);
  assert.ok(!('error' in ok));
  assert.equal(ok.mimeType, 'image/png');
  assert.equal(ok.bytes, 11);

  assert.ok('error' in parseImageData('data:image/svg+xml;base64,AAAA'));
  assert.ok('error' in parseImageData('data:image/png;base64,@@@@'));
  assert.ok('error' in parseImageData(''));
  assert.ok('error' in parseImageData(`data:image/png;base64,${png}`, 5));
  const bare = parseImageData(png);
  assert.ok(!('error' in bare));
  assert.equal(bare.mimeType, 'image/jpeg');
});

test('parseAudioMime detects raw PCM and sample rate', () => {
  assert.deepEqual(parseAudioMime('audio/L16;codec=pcm;rate=24000'), { isRawPcm: true, sampleRate: 24000 });
  assert.deepEqual(parseAudioMime('audio/pcm;rate=16000'), { isRawPcm: true, sampleRate: 16000 });
  assert.equal(parseAudioMime('audio/wav').isRawPcm, false);
  assert.equal(parseAudioMime(undefined).isRawPcm, true);
});

test('pcmToWav writes a valid 44-byte RIFF header', () => {
  const pcm = Buffer.alloc(480, 1);
  const wav = pcmToWav(pcm, 24000);
  assert.equal(wav.length, 44 + 480);
  assert.equal(wav.toString('ascii', 0, 4), 'RIFF');
  assert.equal(wav.toString('ascii', 8, 12), 'WAVE');
  assert.equal(wav.readUInt32LE(4), 36 + 480);
  assert.equal(wav.readUInt16LE(20), 1);
  assert.equal(wav.readUInt16LE(22), 1);
  assert.equal(wav.readUInt32LE(24), 24000);
  assert.equal(wav.readUInt32LE(28), 48000);
  assert.equal(wav.readUInt16LE(34), 16);
  assert.equal(wav.readUInt32LE(40), 480);
});

test('cleanForSpeech strips markdown, code and links', () => {
  assert.equal(cleanForSpeech('**Hello** `x` see https://a.com now ```code```'), 'Hello x see now');
  assert.equal(cleanForSpeech('a'.repeat(900)).length, 800);
});

/* ---------------- SSRF protection ---------------- */

test('isPrivateAddress blocks non-public IPv4 and IPv6', () => {
  for (const ip of [
    '127.0.0.1',
    '10.1.2.3',
    '172.16.0.1',
    '172.31.255.255',
    '192.168.1.1',
    '169.254.169.254',
    '100.64.0.1',
    '0.0.0.0',
    '224.0.0.1',
    '255.255.255.255',
    '::1',
    '::',
    'fe80::1',
    'fc00::1',
    'fd12:3456::1',
    '::ffff:127.0.0.1',
    '::ffff:7f00:1',
    '::ffff:a00:1',
    'ff02::1',
    '2001:db8::1',
    'not-an-ip',
  ]) {
    assert.equal(isPrivateAddress(ip), true, `${ip} should be blocked`);
  }
});

test('isPrivateAddress allows public addresses', () => {
  for (const ip of ['8.8.8.8', '1.1.1.1', '93.184.216.34', '172.32.0.1', '2606:4700:4700::1111', '::ffff:8.8.8.8']) {
    assert.equal(isPrivateAddress(ip), false, `${ip} should be allowed`);
  }
});

test('parsePublicHttpUrl rejects dangerous URLs', () => {
  for (const url of [
    'file:///etc/passwd',
    'ftp://example.com',
    'javascript:alert(1)',
    'http://localhost:3000/',
    'http://127.0.0.1/',
    'http://[::1]/',
    'http://169.254.169.254/latest/meta-data/',
    'http://metadata.google.internal/',
    'http://printer.local/',
    'https://user:pass@example.com/',
    'not a url',
    '',
  ]) {
    assert.throws(() => parsePublicHttpUrl(url), UrlBlockedError, `${url} should be blocked`);
  }
  assert.equal(parsePublicHttpUrl('https://example.com/a?b=1').hostname, 'example.com');
});

test('guardedLookup refuses hostnames that resolve to private addresses', async () => {
  const result = await new Promise<{ err: Error | null }>((resolve) => {
    guardedLookup('localhost', {}, (err) => resolve({ err }));
  });
  assert.ok(result.err instanceof UrlBlockedError);
});

test('fetchPublicPage never contacts a local server', async () => {
  let hits = 0;
  const server = http.createServer((_req, res) => {
    hits += 1;
    res.end('secret');
  });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address() as AddressInfo;
  try {
    await assert.rejects(fetchPublicPage(`http://127.0.0.1:${port}/`), UrlBlockedError);
    await assert.rejects(fetchPublicPage(`http://localhost:${port}/`), UrlBlockedError);
    assert.equal(hits, 0);
  } finally {
    server.close();
  }
});

test('fetch pipeline: redirects, size cap, content-type and errors (permissive test policy)', async () => {
  const server = http.createServer((req, res) => {
    if (req.url === '/redirect') {
      res.writeHead(302, { Location: '/page' });
      res.end();
    } else if (req.url === '/loop') {
      res.writeHead(302, { Location: '/loop' });
      res.end();
    } else if (req.url === '/page') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end('<html><head><title>Hi &amp; bye</title></head><body><script>x()</script><p>Hello</p></body></html>');
    } else if (req.url === '/big') {
      res.writeHead(200, { 'Content-Type': 'text/plain' });
      res.end('a'.repeat(5000));
    } else if (req.url === '/image') {
      res.writeHead(200, { 'Content-Type': 'image/png' });
      res.end(Buffer.alloc(10));
    } else if (req.url === '/slow') {
      // never responds
    } else {
      res.writeHead(404);
      res.end('nope');
    }
  });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address() as AddressInfo;
  const base = `http://127.0.0.1:${port}`;
  const policy = {
    validateUrl: (u: string) => new URL(u),
    lookup: ((host: string, _o: unknown, cb: (e: null, a: string, f: number) => void) => cb(null, '127.0.0.1', 4)) as never,
  };
  try {
    const page = await fetchPageWithPolicy(`${base}/redirect`, {}, policy);
    assert.equal(page.status, 200);
    assert.ok(page.finalUrl.endsWith('/page'));
    const text = htmlToText(page.body);
    assert.equal(text.title, 'Hi & bye');
    assert.equal(text.text, 'Hello');

    const big = await fetchPageWithPolicy(`${base}/big`, { maxBytes: 1000 }, policy);
    assert.equal(big.truncated, true);
    assert.equal(big.body.length, 1000);

    await assert.rejects(fetchPageWithPolicy(`${base}/image`, {}, policy), (e: unknown) => e instanceof FetchPageError && e.code === 'UNSUPPORTED_CONTENT');
    await assert.rejects(fetchPageWithPolicy(`${base}/missing`, {}, policy), (e: unknown) => e instanceof FetchPageError && e.code === 'HTTP_ERROR' && e.upstreamStatus === 404);
    await assert.rejects(fetchPageWithPolicy(`${base}/loop`, { maxRedirects: 3 }, policy), (e: unknown) => e instanceof FetchPageError && e.code === 'TOO_MANY_REDIRECTS');
    await assert.rejects(fetchPageWithPolicy(`${base}/slow`, { timeoutMs: 300 }, policy), (e: unknown) => e instanceof FetchPageError && e.code === 'TIMEOUT');
  } finally {
    server.closeAllConnections();
    server.close();
  }
});

test('dns sanity: localhost resolves locally (guards the lookup test above)', async () => {
  const addrs = await dns.promises.lookup('localhost', { all: true });
  assert.ok(addrs.length > 0);
});

/* ---------------- html ---------------- */

test('htmlToText removes scripts/styles and decodes entities', () => {
  const { title, text } = htmlToText(
    '<title> A &amp; B </title><style>p{color:red}</style><div>One</div><div>Two &#38; &#x41;</div><!-- c --><script>bad()</script>'
  );
  assert.equal(title, 'A & B');
  assert.equal(text, 'One\nTwo & A');
});

test('estimateReadingTime', () => {
  assert.equal(estimateReadingTime('word '.repeat(450)), '3 min read');
  assert.equal(estimateReadingTime(''), '1 min read');
});

/* ---------------- rate limit & CORS ---------------- */

test('RateLimiter allows up to max then blocks until the window resets', () => {
  const rl = new RateLimiter(2, 1000);
  assert.equal(rl.check('ip', 0).allowed, true);
  assert.equal(rl.check('ip', 10).allowed, true);
  const blocked = rl.check('ip', 20);
  assert.equal(blocked.allowed, false);
  assert.ok(blocked.retryAfterSec >= 1);
  assert.equal(rl.check('other', 20).allowed, true);
  assert.equal(rl.check('ip', 1500).allowed, true);
});

test('isOriginAllowed is an exact match unless * is configured', () => {
  const allowed = ['https://appassets.androidplatform.net'];
  assert.equal(isOriginAllowed('https://appassets.androidplatform.net', allowed), true);
  assert.equal(isOriginAllowed('https://evil.example', allowed), false);
  assert.equal(isOriginAllowed(undefined, allowed), false);
  assert.equal(isOriginAllowed('https://anything', ['*']), true);
});
