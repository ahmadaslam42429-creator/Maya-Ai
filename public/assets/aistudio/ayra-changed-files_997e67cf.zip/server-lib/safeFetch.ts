/**
 * AYRA AI — SSRF-safe page fetcher used by /api/browser/read.
 *
 * Why not plain fetch()? A server that fetches user-supplied URLs can be tricked
 * into reading internal services (cloud metadata, localhost admin ports, ...).
 * This module:
 *  - only allows http/https,
 *  - resolves DNS itself and refuses private/loopback/link-local addresses
 *    (the validated address is the one the socket connects to, which also
 *    defeats DNS-rebinding),
 *  - follows redirects manually and re-validates every hop,
 *  - enforces a total timeout and a maximum body size,
 *  - only accepts text-like content types.
 */

import dns from 'node:dns';
import http from 'node:http';
import https from 'node:https';
import zlib from 'node:zlib';
import type { LookupFunction } from 'node:net';
import { Buffer } from 'node:buffer';
import { isPrivateAddress, parsePublicHttpUrl, UrlBlockedError } from './utils.ts';

export type FetchPageErrorCode =
  | 'BLOCKED'
  | 'TIMEOUT'
  | 'TOO_MANY_REDIRECTS'
  | 'UNSUPPORTED_CONTENT'
  | 'HTTP_ERROR'
  | 'NETWORK';

export class FetchPageError extends Error {
  code: FetchPageErrorCode;
  upstreamStatus: number | undefined;

  constructor(code: FetchPageErrorCode, message: string, upstreamStatus?: number) {
    super(message);
    this.name = 'FetchPageError';
    this.code = code;
    this.upstreamStatus = upstreamStatus;
  }
}

export interface FetchedPage {
  finalUrl: string;
  status: number;
  contentType: string;
  body: string;
  truncated: boolean;
}

export interface FetchPageOptions {
  timeoutMs?: number;
  maxBytes?: number;
  maxRedirects?: number;
}

/** DNS lookup that rejects hostnames resolving to any non-public address. */
export const guardedLookup: LookupFunction = (hostname, options, callback) => {
  dns.lookup(hostname, { all: true }, (error, addresses) => {
    if (error) {
      callback(error, '', 4);
      return;
    }
    if (addresses.length === 0 || addresses.some((a) => isPrivateAddress(a.address))) {
      callback(new UrlBlockedError('That address resolves to a private network and cannot be read.'), '', 4);
      return;
    }
    if ((options as { all?: boolean }).all) {
      // Node >= 20 may ask for every address (happy eyeballs).
      (callback as unknown as (err: null, list: dns.LookupAddress[]) => void)(null, addresses);
    } else {
      callback(null, addresses[0].address, addresses[0].family);
    }
  });
};

interface HopResult {
  status: number;
  location: string | null;
  contentType: string;
  body: Buffer;
  truncated: boolean;
}

function requestOnce(url: URL, deadlineAt: number, maxBytes: number, lookup: LookupFunction): Promise<HopResult> {
  return new Promise<HopResult>((resolve, reject) => {
    const remaining = deadlineAt - Date.now();
    if (remaining <= 0) {
      reject(new FetchPageError('TIMEOUT', 'The page took too long to respond.'));
      return;
    }

    let settled = false;
    const finish = (fn: () => void) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      fn();
    };

    const lib = url.protocol === 'https:' ? https : http;
    const req = lib.request(
      url,
      {
        method: 'GET',
        lookup,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 14; AYRA-AI) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36',
          Accept: 'text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.5',
          'Accept-Encoding': 'gzip, deflate, br',
        },
      },
      (res) => {
        const status = res.statusCode ?? 0;
        const contentType = String(res.headers['content-type'] ?? '');
        const location = typeof res.headers.location === 'string' ? res.headers.location : null;

        if (status >= 300 && status < 400 && location) {
          res.resume();
          finish(() => resolve({ status, location, contentType, body: Buffer.alloc(0), truncated: false }));
          return;
        }

        const encoding = String(res.headers['content-encoding'] ?? '').toLowerCase();
        let source: NodeJS.ReadableStream = res;
        if (encoding === 'gzip' || encoding === 'x-gzip') source = res.pipe(zlib.createGunzip());
        else if (encoding === 'deflate') source = res.pipe(zlib.createInflate());
        else if (encoding === 'br') source = res.pipe(zlib.createBrotliDecompress());

        const chunks: Buffer[] = [];
        let size = 0;
        let truncated = false;

        source.on('data', (chunk: Buffer) => {
          if (truncated) return;
          size += chunk.length;
          if (size > maxBytes) {
            chunks.push(chunk.subarray(0, chunk.length - (size - maxBytes)));
            truncated = true;
            res.destroy();
            finish(() => resolve({ status, location: null, contentType, body: Buffer.concat(chunks), truncated }));
            return;
          }
          chunks.push(chunk);
        });
        source.on('end', () => finish(() => resolve({ status, location: null, contentType, body: Buffer.concat(chunks), truncated })));
        source.on('error', (err: Error) => {
          if (truncated) return;
          finish(() => reject(new FetchPageError('NETWORK', `The page could not be read: ${err.message}`)));
        });
      }
    );

    const timer = setTimeout(() => {
      req.destroy();
      finish(() => reject(new FetchPageError('TIMEOUT', 'The page took too long to respond.')));
    }, remaining);

    req.on('error', (err: Error) => {
      if (err instanceof UrlBlockedError) finish(() => reject(new FetchPageError('BLOCKED', err.message)));
      else finish(() => reject(new FetchPageError('NETWORK', `The page could not be reached: ${err.message}`)));
    });
    req.end();
  });
}

function isReadableContentType(contentType: string): boolean {
  const type = contentType.toLowerCase().split(';')[0].trim();
  return type === '' || type.startsWith('text/') || type === 'application/xhtml+xml' || type === 'application/json';
}

function decodeBody(body: Buffer, contentType: string): string {
  const charset = contentType.match(/charset=["']?([\w-]+)/i)?.[1] ?? 'utf-8';
  try {
    return new TextDecoder(charset).decode(body);
  } catch {
    return new TextDecoder('utf-8').decode(body);
  }
}

/** Hooks that decide which hosts may be contacted. Production always uses the strict policy below. */
export interface FetchPolicy {
  validateUrl: (input: string) => URL;
  lookup: LookupFunction;
}

const STRICT_POLICY: FetchPolicy = { validateUrl: parsePublicHttpUrl, lookup: guardedLookup };

/**
 * Policy-parameterised fetch. Exported for unit tests (which need to talk to a
 * local test server); server code must call fetchPublicPage() instead.
 */
export async function fetchPageWithPolicy(input: string, options: FetchPageOptions, policy: FetchPolicy): Promise<FetchedPage> {
  const timeoutMs = options.timeoutMs ?? 10000;
  const maxBytes = options.maxBytes ?? 2 * 1024 * 1024;
  const maxRedirects = options.maxRedirects ?? 5;
  const deadlineAt = Date.now() + timeoutMs;

  let current = policy.validateUrl(input);

  for (let hop = 0; hop <= maxRedirects; hop += 1) {
    const result = await requestOnce(current, deadlineAt, maxBytes, policy.lookup);

    if (result.location) {
      let next: URL;
      try {
        next = new URL(result.location, current);
      } catch {
        throw new FetchPageError('HTTP_ERROR', 'The page redirected to an invalid address.', result.status);
      }
      current = policy.validateUrl(next.toString()); // re-validate every hop
      continue;
    }

    if (result.status < 200 || result.status >= 300) {
      throw new FetchPageError('HTTP_ERROR', `The website responded with HTTP ${result.status}.`, result.status);
    }
    if (!isReadableContentType(result.contentType)) {
      throw new FetchPageError('UNSUPPORTED_CONTENT', 'This page is not a readable text document.');
    }

    return {
      finalUrl: current.toString(),
      status: result.status,
      contentType: result.contentType,
      body: decodeBody(result.body, result.contentType),
      truncated: result.truncated,
    };
  }

  throw new FetchPageError('TOO_MANY_REDIRECTS', 'The page redirected too many times.');
}

/** Fetches a public web page as text. Throws FetchPageError / UrlBlockedError on any problem. */
export function fetchPublicPage(input: string, options: FetchPageOptions = {}): Promise<FetchedPage> {
  return fetchPageWithPolicy(input, options, STRICT_POLICY);
}
