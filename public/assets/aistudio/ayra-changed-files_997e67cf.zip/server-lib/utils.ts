/**
 * AYRA AI — dependency-free server helpers.
 *
 * Everything in this file is a pure function (or a tiny class) with no
 * third-party imports, so it can be unit-tested with `node --test` without
 * installing any packages. server.ts wires these helpers to Express and Gemini.
 *
 * NOTE: keep this file "erasable TypeScript" (no enums, namespaces or
 * constructor parameter properties) so it also runs under Node's built-in
 * type stripping (`node server.ts`).
 */

import { Buffer } from 'node:buffer';
import { isIP } from 'node:net';
import { timingSafeEqual } from 'node:crypto';

/* ------------------------------------------------------------------ */
/* Types                                                                */
/* ------------------------------------------------------------------ */

export type LanguageCode = 'auto' | 'en' | 'ur' | 'hi';

export const EMOTIONS = ['happy', 'thinking', 'excited', 'caring', 'confused', 'serious', 'sad'] as const;
export type Emotion = (typeof EMOTIONS)[number];

export const ACTION_TYPES = [
  'call',
  'alarm',
  'reminder',
  'open_app',
  'open_url',
  'weather',
  'calculator',
  'note',
  'search',
  'share',
] as const;
export type ActionType = (typeof ACTION_TYPES)[number];

export interface AssistantAction {
  type: ActionType;
  title: string;
  description: string;
  payload: Record<string, string | number>;
  requiresConfirmation: boolean;
}

export interface GeminiTurn {
  role: 'user' | 'model';
  parts: Array<{ text: string }>;
}

/* ------------------------------------------------------------------ */
/* Small validators                                                     */
/* ------------------------------------------------------------------ */

export function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/** Returns a trimmed string when `value` is a string within [1, max] chars, otherwise null. */
export function readText(value: unknown, max: number): string | null {
  if (typeof value !== 'string') return null;
  const trimmed = value.trim();
  if (trimmed.length === 0 || trimmed.length > max) return null;
  return trimmed;
}

/** Trims and truncates an optional free-text field. Returns fallback when missing/invalid. */
export function readOptionalText(value: unknown, max: number, fallback = ''): string {
  if (typeof value !== 'string') return fallback;
  return value.trim().slice(0, max) || fallback;
}

export function parseLanguage(value: unknown): LanguageCode {
  return value === 'en' || value === 'ur' || value === 'hi' || value === 'auto' ? value : 'auto';
}

export function parseEmotion(value: unknown): Emotion {
  return (EMOTIONS as readonly string[]).includes(String(value)) ? (value as Emotion) : 'happy';
}

/** Languages the assistant is built around. Used only to steer prompts. */
export function languageLabel(lang: LanguageCode): string {
  switch (lang) {
    case 'ur':
      return 'Urdu (the user may write in Urdu script or in Roman Urdu)';
    case 'hi':
      return 'Hindi (the user may write in Devanagari or in Roman Hindi)';
    case 'en':
      return 'English';
    default:
      return 'the same language and script the user writes in (English, Urdu, Roman Urdu or Hindi)';
  }
}

/* ------------------------------------------------------------------ */
/* Conversation history                                                 */
/* ------------------------------------------------------------------ */

/**
 * Converts client-supplied history into valid Gemini turns:
 * - accepts {role, text} or {role, content}; 'assistant'/'model'/'ayra' => model
 * - drops empty/unknown roles, truncates long turns, keeps the last `maxTurns`
 * - merges consecutive turns of the same role
 * - guarantees the first turn is a user turn
 */
export function normalizeHistory(raw: unknown, maxTurns = 16, maxChars = 2000): GeminiTurn[] {
  if (!Array.isArray(raw)) return [];
  const out: GeminiTurn[] = [];

  for (const item of raw.slice(-maxTurns)) {
    if (!isPlainObject(item)) continue;
    const roleRaw = String(item.role ?? '').toLowerCase();
    const role: 'user' | 'model' | null =
      roleRaw === 'user' ? 'user' : roleRaw === 'assistant' || roleRaw === 'model' || roleRaw === 'ayra' ? 'model' : null;
    if (!role) continue;

    const text = typeof item.text === 'string' ? item.text : typeof item.content === 'string' ? item.content : '';
    const trimmed = text.trim().slice(0, maxChars);
    if (!trimmed) continue;

    const last = out[out.length - 1];
    if (last && last.role === role) {
      last.parts[0].text += `\n${trimmed}`;
    } else {
      out.push({ role, parts: [{ text: trimmed }] });
    }
  }

  while (out.length > 0 && out[0].role !== 'user') out.shift();
  return out;
}

/** Appends the new user message to normalized history (merging if the last turn is also a user turn). */
export function buildChatContents(history: GeminiTurn[], message: string): GeminiTurn[] {
  const contents = history.map((t) => ({ role: t.role, parts: [{ text: t.parts[0].text }] }));
  const last = contents[contents.length - 1];
  if (last && last.role === 'user') {
    last.parts[0].text += `\n${message}`;
  } else {
    contents.push({ role: 'user', parts: [{ text: message }] });
  }
  return contents;
}

/* ------------------------------------------------------------------ */
/* Model output parsing                                                 */
/* ------------------------------------------------------------------ */

/** Parses a JSON object out of model text (plain JSON, fenced JSON, or JSON embedded in prose). */
export function extractJsonObject(raw: unknown): Record<string, unknown> | null {
  if (typeof raw !== 'string') return null;
  const text = raw.trim();
  if (!text) return null;

  const candidates: string[] = [text];
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fenced) candidates.push(fenced[1].trim());
  const first = text.indexOf('{');
  const last = text.lastIndexOf('}');
  if (first !== -1 && last > first) candidates.push(text.slice(first, last + 1));

  for (const candidate of candidates) {
    try {
      const parsed: unknown = JSON.parse(candidate);
      if (isPlainObject(parsed)) return parsed;
    } catch {
      // try next candidate
    }
  }
  return null;
}

/** Keeps only the allowed keys of a payload, coercing values to short strings/numbers. */
function pickPayload(raw: unknown, keys: readonly string[]): Record<string, string | number> {
  const out: Record<string, string | number> = {};
  if (!isPlainObject(raw)) return out;
  for (const key of keys) {
    const value = raw[key];
    if (typeof value === 'string' && value.trim()) out[key] = value.trim().slice(0, 500);
    else if (typeof value === 'number' && Number.isFinite(value)) out[key] = value;
  }
  return out;
}

const PHONE_PATTERN = /^\+?[0-9][0-9 ()-]{2,19}$/;
const TIME_PATTERN = /^([01]?[0-9]|2[0-3]):([0-5][0-9])$/;

/** Actions that can cost money, contact people or leave the app must always be user-confirmed. */
const ALWAYS_CONFIRM: readonly ActionType[] = ['call', 'share', 'open_url', 'alarm', 'reminder'];

/**
 * Validates a model-proposed device action. Returns null when the action is
 * malformed or unsafe. The model can only *propose*; the Android UI executes
 * after confirmation.
 */
export function sanitizeAction(raw: unknown): AssistantAction | null {
  if (!isPlainObject(raw)) return null;
  const type = raw.type;
  if (typeof type !== 'string' || !(ACTION_TYPES as readonly string[]).includes(type)) return null;
  const actionType = type as ActionType;

  let payload: Record<string, string | number> = {};
  switch (actionType) {
    case 'call': {
      payload = pickPayload(raw.payload, ['number', 'contactName']);
      const number = String(payload.number ?? '');
      if (!PHONE_PATTERN.test(number)) return null;
      break;
    }
    case 'alarm': {
      payload = pickPayload(raw.payload, ['time', 'label', 'durationMinutes']);
      if (payload.time !== undefined && !TIME_PATTERN.test(String(payload.time))) return null;
      break;
    }
    case 'reminder':
      payload = pickPayload(raw.payload, ['title', 'time', 'due']);
      break;
    case 'open_app':
      payload = pickPayload(raw.payload, ['appName', 'query']);
      if (!payload.appName) return null;
      break;
    case 'open_url': {
      payload = pickPayload(raw.payload, ['url']);
      try {
        const u = new URL(String(payload.url ?? ''));
        if (u.protocol !== 'https:' && u.protocol !== 'http:') return null;
        payload.url = u.toString();
      } catch {
        return null;
      }
      break;
    }
    case 'weather':
      payload = pickPayload(raw.payload, ['city']);
      break;
    case 'calculator':
      payload = pickPayload(raw.payload, ['expression']);
      break;
    case 'note':
      payload = pickPayload(raw.payload, ['title', 'content']);
      break;
    case 'search':
      payload = pickPayload(raw.payload, ['query']);
      break;
    case 'share':
      payload = pickPayload(raw.payload, ['text', 'number', 'app']);
      break;
  }

  const requiresConfirmation = ALWAYS_CONFIRM.includes(actionType) ? true : raw.requiresConfirmation !== false;

  return {
    type: actionType,
    title: readOptionalText(raw.title, 80, actionType),
    description: readOptionalText(raw.description, 240),
    payload,
    requiresConfirmation,
  };
}

/* ------------------------------------------------------------------ */
/* Images (vision)                                                      */
/* ------------------------------------------------------------------ */

const IMAGE_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/heif'] as const;

export interface ParsedImage {
  mimeType: string;
  base64: string;
  bytes: number;
}

/**
 * Accepts a `data:image/...;base64,...` URL (or bare base64, assumed JPEG)
 * and validates mime type, charset and decoded size.
 */
export function parseImageData(input: unknown, maxBytes = 8 * 1024 * 1024): ParsedImage | { error: string } {
  if (typeof input !== 'string' || input.length === 0) return { error: 'Image data is required.' };

  let mimeType = 'image/jpeg';
  let base64 = input.trim();
  const match = base64.match(/^data:([a-zA-Z0-9.+/-]+);base64,/);
  if (match) {
    mimeType = match[1].toLowerCase();
    base64 = base64.slice(match[0].length);
  }
  if (mimeType === 'image/jpg') mimeType = 'image/jpeg';
  if (!(IMAGE_MIME_TYPES as readonly string[]).includes(mimeType)) {
    return { error: `Unsupported image type "${mimeType}". Use JPEG, PNG, WebP, HEIC or HEIF.` };
  }
  if (!/^[A-Za-z0-9+/]+={0,2}$/.test(base64)) return { error: 'Image data is not valid base64.' };

  const padding = base64.endsWith('==') ? 2 : base64.endsWith('=') ? 1 : 0;
  const bytes = Math.floor((base64.length * 3) / 4) - padding;
  if (bytes <= 0) return { error: 'Image data is empty.' };
  if (bytes > maxBytes) return { error: `Image is too large (max ${Math.round(maxBytes / (1024 * 1024))} MB).` };
  return { mimeType, base64, bytes };
}

/* ------------------------------------------------------------------ */
/* Audio (TTS)                                                          */
/* ------------------------------------------------------------------ */

export interface AudioMimeInfo {
  isRawPcm: boolean;
  sampleRate: number;
}

/** Gemini TTS returns raw PCM ("audio/L16;codec=pcm;rate=24000") or a WAV container. */
export function parseAudioMime(mimeType: string | undefined | null): AudioMimeInfo {
  const mime = (mimeType || '').toLowerCase();
  const rate = mime.match(/rate=(\d{4,6})/);
  const isWav = mime.includes('wav') || mime.includes('wave');
  const isRawPcm = !isWav && (mime.includes('l16') || mime.includes('pcm') || mime === '');
  return { isRawPcm, sampleRate: rate ? Number(rate[1]) : 24000 };
}

/** Wraps 16-bit little-endian mono PCM in a 44-byte WAV header so browsers can play it. */
export function pcmToWav(pcm: Buffer, sampleRate = 24000, channels = 1, bitsPerSample = 16): Buffer {
  const byteRate = (sampleRate * channels * bitsPerSample) / 8;
  const blockAlign = (channels * bitsPerSample) / 8;
  const header = Buffer.alloc(44);
  header.write('RIFF', 0, 'ascii');
  header.writeUInt32LE(36 + pcm.length, 4);
  header.write('WAVE', 8, 'ascii');
  header.write('fmt ', 12, 'ascii');
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20); // PCM
  header.writeUInt16LE(channels, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(byteRate, 28);
  header.writeUInt16LE(blockAlign, 32);
  header.writeUInt16LE(bitsPerSample, 34);
  header.write('data', 36, 'ascii');
  header.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([header, pcm]);
}

/** Strips markdown/code/URLs so text reads naturally when spoken. */
export function cleanForSpeech(text: string, maxChars = 800): string {
  return text
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/https?:\/\/\S+/g, ' ')
    .replace(/[*_~#>]+/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, maxChars);
}

/* ------------------------------------------------------------------ */
/* Network safety (SSRF protection for /api/browser/read)               */
/* ------------------------------------------------------------------ */

function parseIpv4(ip: string): number[] | null {
  const parts = ip.split('.');
  if (parts.length !== 4) return null;
  const nums = parts.map((p) => (/^\d{1,3}$/.test(p) ? Number(p) : NaN));
  return nums.every((n) => n >= 0 && n <= 255) ? nums : null;
}

function isPrivateIpv4(o: number[]): boolean {
  const [a, b] = o;
  return (
    a === 0 ||
    a === 10 ||
    a === 127 ||
    (a === 100 && b >= 64 && b <= 127) || // carrier-grade NAT
    (a === 169 && b === 254) || // link-local / cloud metadata
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 0 && o[2] === 0) ||
    (a === 192 && b === 168) ||
    (a === 198 && (b === 18 || b === 19)) ||
    a >= 224 // multicast + reserved + broadcast
  );
}

/** Expands an IPv6 literal to 8 hextets, supporting "::" and an embedded IPv4 tail. Returns null when invalid. */
function expandIpv6(ip: string): number[] | null {
  let text = ip.toLowerCase();
  const zone = text.indexOf('%');
  if (zone !== -1) text = text.slice(0, zone);

  const lastColon = text.lastIndexOf(':');
  if (lastColon === -1) return null;
  const tail = text.slice(lastColon + 1);
  if (tail.includes('.')) {
    const v4 = parseIpv4(tail);
    if (!v4) return null;
    text = `${text.slice(0, lastColon + 1)}${((v4[0] << 8) | v4[1]).toString(16)}:${((v4[2] << 8) | v4[3]).toString(16)}`;
  }

  const halves = text.split('::');
  if (halves.length > 2) return null;
  const head = halves[0] ? halves[0].split(':') : [];
  const rest = halves.length === 2 && halves[1] ? halves[1].split(':') : [];
  const missing = 8 - head.length - rest.length;
  if (halves.length === 1 ? head.length !== 8 : missing < 1) return null;

  const groups = halves.length === 1 ? head : [...head, ...Array(missing).fill('0'), ...rest];
  const nums = groups.map((g) => (/^[0-9a-f]{1,4}$/.test(g) ? parseInt(g, 16) : NaN));
  return nums.length === 8 && nums.every((n) => !Number.isNaN(n)) ? nums : null;
}

/** True for loopback, private, link-local, metadata, multicast and otherwise non-public addresses. */
export function isPrivateAddress(address: string): boolean {
  const family = isIP(address);
  if (family === 4) {
    const octets = parseIpv4(address);
    return octets ? isPrivateIpv4(octets) : true;
  }
  if (family === 6) {
    const g = expandIpv6(address);
    if (!g) return true;
    const allZeroPrefix = g.slice(0, 5).every((n) => n === 0);
    if (allZeroPrefix && g[5] === 0 && g[6] === 0 && (g[7] === 0 || g[7] === 1)) return true; // :: and ::1
    if (allZeroPrefix && g[5] === 0xffff) {
      // IPv4-mapped (::ffff:a.b.c.d)
      return isPrivateIpv4([g[6] >> 8, g[6] & 255, g[7] >> 8, g[7] & 255]);
    }
    if (allZeroPrefix && g[5] === 0) return true; // deprecated IPv4-compatible (::a.b.c.d)
    if ((g[0] & 0xfe00) === 0xfc00) return true; // fc00::/7 unique local
    if ((g[0] & 0xffc0) === 0xfe80) return true; // fe80::/10 link-local
    if ((g[0] & 0xff00) === 0xff00) return true; // multicast
    if (g[0] === 0x2001 && g[1] === 0x0db8) return true; // documentation
    if (g[0] === 0x0064 && g[1] === 0xff9b) return true; // NAT64
    return false;
  }
  return true; // not an IP literal
}

export class UrlBlockedError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'UrlBlockedError';
  }
}

/** Parses and statically validates a user-supplied URL (scheme, credentials, obviously-internal hostnames). */
export function parsePublicHttpUrl(input: unknown): URL {
  if (typeof input !== 'string' || !input.trim()) throw new UrlBlockedError('A URL is required.');
  let url: URL;
  try {
    url = new URL(input.trim());
  } catch {
    throw new UrlBlockedError('The URL is not valid.');
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') {
    throw new UrlBlockedError('Only http and https URLs can be read.');
  }
  if (url.username || url.password) throw new UrlBlockedError('URLs with embedded credentials are not allowed.');

  const host = url.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (
    host === 'localhost' ||
    host.endsWith('.localhost') ||
    host.endsWith('.local') ||
    host.endsWith('.internal') ||
    host.endsWith('.lan') ||
    host === 'metadata.google.internal'
  ) {
    throw new UrlBlockedError('Internal hostnames cannot be read.');
  }
  if (isIP(host) && isPrivateAddress(host)) throw new UrlBlockedError('Private network addresses cannot be read.');
  return url;
}

/* ------------------------------------------------------------------ */
/* HTML -> text                                                         */
/* ------------------------------------------------------------------ */

const ENTITY_MAP: Record<string, string> = {
  amp: '&',
  lt: '<',
  gt: '>',
  quot: '"',
  apos: "'",
  nbsp: ' ',
  ndash: '–',
  mdash: '—',
  hellip: '…',
};

function decodeEntities(text: string): string {
  return text.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (match, entity: string) => {
    if (entity[0] === '#') {
      const code = entity[1].toLowerCase() === 'x' ? parseInt(entity.slice(2), 16) : parseInt(entity.slice(1), 10);
      return Number.isFinite(code) && code > 0 && code < 0x110000 ? String.fromCodePoint(code) : match;
    }
    return ENTITY_MAP[entity.toLowerCase()] ?? match;
  });
}

export interface ExtractedPage {
  title: string;
  text: string;
}

export function htmlToText(html: string, maxChars = 12000): ExtractedPage {
  const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const title = titleMatch ? decodeEntities(titleMatch[1]).replace(/\s+/g, ' ').trim().slice(0, 200) : '';

  const body = html
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<(script|style|noscript|svg|template|iframe|canvas|title)\b[\s\S]*?<\/\1\s*>/gi, ' ')
    .replace(/<\/(p|div|section|article|li|h[1-6]|tr|br)\s*>|<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, ' ');

  const text = decodeEntities(body)
    .replace(/[ \t\f\v]+/g, ' ')
    .replace(/ ?\n ?/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim()
    .slice(0, maxChars);

  return { title, text };
}

/* ------------------------------------------------------------------ */
/* Rate limiting, CORS, auth                                            */
/* ------------------------------------------------------------------ */

/** Fixed-window in-memory limiter. Good enough for a single-instance deployment. */
export class RateLimiter {
  private readonly windowMs: number;
  private readonly max: number;
  private readonly hits = new Map<string, { count: number; resetAt: number }>();

  constructor(max: number, windowMs: number) {
    this.max = max;
    this.windowMs = windowMs;
  }

  /** Returns {allowed, retryAfterSec}. */
  check(key: string, now = Date.now()): { allowed: boolean; retryAfterSec: number } {
    if (this.hits.size > 10000) this.prune(now);
    const entry = this.hits.get(key);
    if (!entry || entry.resetAt <= now) {
      this.hits.set(key, { count: 1, resetAt: now + this.windowMs });
      return { allowed: true, retryAfterSec: 0 };
    }
    entry.count += 1;
    if (entry.count > this.max) return { allowed: false, retryAfterSec: Math.max(1, Math.ceil((entry.resetAt - now) / 1000)) };
    return { allowed: true, retryAfterSec: 0 };
  }

  private prune(now: number): void {
    for (const [key, entry] of this.hits) if (entry.resetAt <= now) this.hits.delete(key);
  }
}

export function parseCsv(value: string | undefined): string[] {
  return (value ?? '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
}

/** Exact-match CORS check; "*" is accepted only if explicitly configured. */
export function isOriginAllowed(origin: string | undefined, allowed: string[]): boolean {
  if (!origin) return false;
  return allowed.includes('*') || allowed.includes(origin);
}

export function safeEqual(a: string, b: string): boolean {
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  return ab.length === bb.length && timingSafeEqual(ab, bb);
}

export function readPositiveInt(value: string | undefined, fallback: number, min = 1, max = Number.MAX_SAFE_INTEGER): number {
  const n = Number(value);
  return Number.isInteger(n) && n >= min && n <= max ? n : fallback;
}

export function estimateReadingTime(text: string): string {
  const words = text.trim().split(/\s+/).filter(Boolean).length;
  return `${Math.max(1, Math.ceil(words / 200))} min read`;
}
