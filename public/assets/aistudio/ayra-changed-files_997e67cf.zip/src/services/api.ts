/**
 * AYRA AI — backend connectivity.
 *
 * The Android APK serves the UI from https://appassets.androidplatform.net/assets/...
 * A relative request such as fetch('/api/gemini/chat') therefore goes to that fake asset
 * origin, where no server exists. Every "/api/..." request is routed to the configured
 * HTTPS backend instead.
 *
 * Backend URL, first match wins:
 *   1. the address saved by the user in Settings -> Connection (localStorage)
 *   2. the address compiled into the APK (AyraNativeBridge.getBackendUrl(), Gradle property ayraBackendUrl)
 *   3. VITE_BACKEND_URL at web build time
 *   4. same origin (correct for the web app served by server.ts)
 *
 * No Gemini key is ever used or stored here; it only exists on the server.
 */

const URL_KEY = 'ayra_backend_url';
const TOKEN_KEY = 'ayra_access_token';
const ANDROID_ASSET_HOST = 'appassets.androidplatform.net';
const DEFAULT_TIMEOUT_MS = 60_000;

export class ApiError extends Error {
  code: string;
  status: number;

  constructor(code: string, message: string, status = 0) {
    super(message);
    this.name = 'ApiError';
    this.code = code;
    this.status = status;
  }
}

function readStore(key: string): string {
  try {
    return window.localStorage.getItem(key) ?? '';
  } catch {
    return '';
  }
}

function writeStore(key: string, value: string): void {
  try {
    if (value) window.localStorage.setItem(key, value);
    else window.localStorage.removeItem(key);
  } catch {
    // storage unavailable (private mode): the setting just won't persist
  }
}

/** Accepts "https://host[:port][/path]" (http only for localhost development). Returns '' when invalid. */
export function normalizeBackendUrl(input: string): string {
  const raw = input.trim().replace(/\/+$/, '');
  if (!raw) return '';
  try {
    const url = new URL(raw);
    const local = url.hostname === 'localhost' || url.hostname === '127.0.0.1' || url.hostname === '10.0.2.2';
    if (url.protocol !== 'https:' && !(url.protocol === 'http:' && local)) return '';
    if (url.username || url.password) return '';
    return `${url.origin}${url.pathname === '/' ? '' : url.pathname.replace(/\/+$/, '')}`;
  } catch {
    return '';
  }
}

export function isAndroidApp(): boolean {
  if (typeof window === 'undefined') return false;
  return window.location.hostname === ANDROID_ASSET_HOST || Boolean((window as any).AyraNativeBridge);
}

function nativeBackendUrl(): string {
  try {
    const bridge = (window as any).AyraNativeBridge;
    if (bridge && typeof bridge.getBackendUrl === 'function') return String(bridge.getBackendUrl() ?? '');
  } catch {
    // bridge missing or failed
  }
  return '';
}

export function getBackendUrl(): string {
  const saved = normalizeBackendUrl(readStore(URL_KEY));
  if (saved) return saved;
  const native = normalizeBackendUrl(nativeBackendUrl());
  if (native) return native;
  const build = normalizeBackendUrl(String((import.meta as any).env?.VITE_BACKEND_URL ?? ''));
  if (build) return build;
  return '';
}

/** Where the backend URL currently comes from (shown in Settings). */
export function getBackendUrlSource(): 'saved' | 'app' | 'build' | 'same-origin' | 'missing' {
  if (normalizeBackendUrl(readStore(URL_KEY))) return 'saved';
  if (normalizeBackendUrl(nativeBackendUrl())) return 'app';
  if (normalizeBackendUrl(String((import.meta as any).env?.VITE_BACKEND_URL ?? ''))) return 'build';
  return isAndroidApp() ? 'missing' : 'same-origin';
}

/** Saves (or clears, with '') the backend address. Returns false when the address is invalid. */
export function setBackendUrl(input: string): boolean {
  if (!input.trim()) {
    writeStore(URL_KEY, '');
    return true;
  }
  const normalized = normalizeBackendUrl(input);
  if (!normalized) return false;
  writeStore(URL_KEY, normalized);
  return true;
}

export const getAccessToken = (): string => readStore(TOKEN_KEY);
export const setAccessToken = (token: string): void => writeStore(TOKEN_KEY, token.trim());

/** Full URL for an API path, or throws ApiError when no backend is reachable by design. */
export function resolveApiUrl(path: string): string {
  const base = getBackendUrl();
  if (base) return `${base}${path}`;
  if (isAndroidApp()) {
    throw new ApiError(
      'BACKEND_NOT_CONFIGURED',
      'No AYRA server address is set. Open Settings → Connection and enter your server\'s HTTPS address.'
    );
  }
  return path; // web app: same origin
}

let installed = false;

/**
 * Routes every fetch('/api/...') in the app to the backend, adds the optional access token and a
 * default timeout. Call once, before the app renders.
 */
export function installApiFetch(): void {
  if (installed || typeof window === 'undefined') return;
  installed = true;
  const originalFetch = window.fetch.bind(window);

  window.fetch = (input: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
    if (typeof input !== 'string' || !input.startsWith('/api/')) return originalFetch(input, init);

    let target: string;
    try {
      target = resolveApiUrl(input);
    } catch (error) {
      return Promise.reject(error);
    }

    const headers = new Headers(init?.headers);
    const token = getAccessToken();
    if (token && target !== input) headers.set('X-Ayra-Token', token);
    else if (token && !isAndroidApp()) headers.set('X-Ayra-Token', token);

    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), DEFAULT_TIMEOUT_MS);
    const outer = init?.signal;
    if (outer) {
      if (outer.aborted) controller.abort();
      else outer.addEventListener('abort', () => controller.abort(), { once: true });
    }

    return originalFetch(target, { ...init, headers, signal: controller.signal })
      .catch((error: unknown) => {
        if (controller.signal.aborted && !(outer && outer.aborted)) {
          throw new ApiError('TIMEOUT', 'The AYRA server took too long to respond.');
        }
        if (error instanceof DOMException && error.name === 'AbortError') throw error;
        throw new ApiError('NETWORK', 'Could not reach the AYRA server. Check your internet connection and the server address in Settings.');
      })
      .finally(() => window.clearTimeout(timer));
  };
}

/** Parses a JSON API response; throws ApiError with the server's message when the call failed. */
export async function readJsonOrThrow(res: Response): Promise<Record<string, any>> {
  let body: any = null;
  try {
    body = await res.json();
  } catch {
    body = null;
  }
  if (!res.ok) {
    const message = typeof body?.error === 'string' ? body.error : `The AYRA server answered with HTTP ${res.status}.`;
    throw new ApiError(typeof body?.code === 'string' ? body.code : `HTTP_${res.status}`, message, res.status);
  }
  if (!body || typeof body !== 'object') {
    throw new ApiError('INVALID_RESPONSE', 'The AYRA server sent a response the app could not read. Is the server address correct?', res.status);
  }
  return body;
}

/** One human-readable line for any error thrown while talking to the backend. */
export function describeApiError(error: unknown): string {
  if (error instanceof ApiError) return error.message;
  if (error instanceof Error && error.message) return error.message;
  return 'Something went wrong while contacting the AYRA server.';
}

export interface HealthResult {
  ok: boolean;
  message: string;
  geminiConfigured?: boolean;
  geminiReachable?: boolean;
}

/** Calls /api/health?deep=1 and explains the result in plain words. */
export async function checkBackendHealth(): Promise<HealthResult> {
  try {
    const res = await fetch('/api/health?deep=1');
    const data = await readJsonOrThrow(res);
    if (data.geminiConfigured === false) {
      return { ok: false, message: 'Server is online, but GEMINI_API_KEY is not set on it.', geminiConfigured: false };
    }
    if (data.geminiReachable === false) {
      return { ok: false, message: `Server is online, but Gemini is not answering: ${data.geminiError ?? 'unknown error'}`, geminiConfigured: true, geminiReachable: false };
    }
    return { ok: true, message: 'Connected. The server and Gemini are working.', geminiConfigured: true, geminiReachable: true };
  } catch (error) {
    return { ok: false, message: describeApiError(error) };
  }
}
