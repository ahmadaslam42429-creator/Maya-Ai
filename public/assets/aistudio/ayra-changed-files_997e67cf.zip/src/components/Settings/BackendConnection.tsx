import React, { useState } from 'react';
import {
  checkBackendHealth,
  getAccessToken,
  getBackendUrl,
  getBackendUrlSource,
  setAccessToken,
  setBackendUrl,
} from '../../services/api';

const SOURCE_LABEL: Record<ReturnType<typeof getBackendUrlSource>, string> = {
  saved: 'saved on this phone',
  app: 'built into this app',
  build: 'set at build time',
  'same-origin': 'same address as this page',
  missing: 'not set',
};

/** Settings → Connection: where the APK finds the AYRA server, with a real connection test. */
export const BackendConnection: React.FC = () => {
  const [url, setUrl] = useState(getBackendUrl());
  const [token, setToken] = useState(getAccessToken());
  const [status, setStatus] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  const saveAndTest = async () => {
    if (!setBackendUrl(url)) {
      setStatus({ ok: false, text: 'Enter a valid https:// address, for example https://ayra.example.com' });
      return;
    }
    setAccessToken(token);
    setBusy(true);
    setStatus({ ok: true, text: 'Testing connection…' });
    const result = await checkBackendHealth();
    setStatus({ ok: result.ok, text: result.message });
    setBusy(false);
  };

  return (
    <section className="rounded-2xl border border-cyan-500/30 bg-[#08142E]/90 p-4 mb-4" aria-label="Server connection">
      <h3 className="text-sm font-bold text-cyan-300 mb-1">Server connection</h3>
      <p className="text-[11px] text-slate-400 mb-3">
        AYRA's brain runs on your own server. Current address: <span className="text-slate-200">{getBackendUrl() || 'none'}</span>{' '}
        ({SOURCE_LABEL[getBackendUrlSource()]})
      </p>

      <label className="block text-[11px] text-slate-400 mb-1" htmlFor="ayra-backend-url">Server address (HTTPS)</label>
      <input
        id="ayra-backend-url"
        value={url}
        onChange={(e) => setUrl(e.target.value)}
        placeholder="https://your-server.example.com"
        inputMode="url"
        autoCapitalize="off"
        autoCorrect="off"
        className="w-full rounded-lg bg-[#040916] border border-cyan-500/30 px-3 py-2 text-sm text-slate-100 mb-3"
      />

      <label className="block text-[11px] text-slate-400 mb-1" htmlFor="ayra-access-token">Access token (only if your server requires one)</label>
      <input
        id="ayra-access-token"
        value={token}
        onChange={(e) => setToken(e.target.value)}
        type="password"
        autoComplete="off"
        className="w-full rounded-lg bg-[#040916] border border-cyan-500/30 px-3 py-2 text-sm text-slate-100 mb-3"
      />

      <button
        onClick={saveAndTest}
        disabled={busy}
        className="px-4 py-2 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 text-xs font-bold disabled:opacity-50"
      >
        {busy ? 'Testing…' : 'Save & test connection'}
      </button>

      {status && (
        <p role="status" className={`mt-3 text-xs ${status.ok ? 'text-emerald-300' : 'text-rose-300'}`}>
          {status.text}
        </p>
      )}
    </section>
  );
};
