import {createRoot} from 'react-dom/client';
import {installApiFetch} from './services/api.ts';
import App from './App.tsx';
import './index.css';

installApiFetch();

createRoot(document.getElementById('root')!).render(<App />);
